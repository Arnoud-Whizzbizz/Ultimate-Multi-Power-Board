SwitchDoc Labs SDL_Arduino_INA3221 Library

SwitchDoc Labs - www.switchdoc.com

Version 1.2 September 2019 - Added Manufacture ID

The INA3221 is Triple-Channel, High-SideMeasurement, Shunt and Bus Voltage Monitor with I2C Interface

It is used in the SwitchDoc Labs Solar Controller Product, SunAirPlus and in a standalone SwitchDoc Labs INA3221 Breakout Board

http://www.switchdoc.com/sunairplus-solar-power-controllerdata-collector/


Thanks to the original Adafruit INA219 library, although very little of it ended up being used  The INA3221 is a much different beast than the INA219.


